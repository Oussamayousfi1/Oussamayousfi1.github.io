from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
import os
import datetime

class PDFGenerator:
    def __init__(self, output_directory="documents"):
        self.output_dir = output_directory
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
        
        # Styles
        self.styles = getSampleStyleSheet()
        self.title_style = self.styles['Heading1']
        self.title_style.alignment = 1  # Centre
        
        self.subtitle_style = self.styles['Heading2']
        self.subtitle_style.alignment = 1
        
        self.normal_style = self.styles['Normal']
        
        self.header_style = ParagraphStyle(
            'Header',
            parent=self.styles['Normal'],
            fontSize=8,
            textColor=colors.gray
        )
        
    def generate_attestation_scolarite(self, student_data):
        """Génère une attestation de scolarité"""
        filename = f"{self.output_dir}/attestation_scolarite_{student_data['NUM_ETUDIANT']}.pdf"
        doc = SimpleDocTemplate(filename, pagesize=A4)
        story = []
        
        # En-tête avec logo
        logo_path = "resources/images/logo_universite.png"
        if os.path.exists(logo_path):
            img = Image(logo_path, width=5*cm, height=2*cm)
            story.append(img)
        
        story.append(Spacer(1, 1*cm))
        story.append(Paragraph("ATTESTATION DE SCOLARITÉ", self.title_style))
        story.append(Spacer(1, 1*cm))
        
        # Corps du document
        today = datetime.datetime.now().strftime("%d/%m/%Y")
        text = f"""
        Je soussigné(e), le Directeur de la scolarité, certifie que 
        l'étudiant(e) {student_data['NOM']} {student_data['PRENOM']}, 
        né(e) le {student_data['DATE_NAISSANCE']} à {student_data['LIEU_NAISSANCE']},
        est régulièrement inscrit(e) à notre établissement pour l'année universitaire {student_data['ANNEE_UNIV']},
        en {student_data['LIBELLE_FORMATION']}.
        
        Cette attestation est délivrée à l'intéressé(e) pour servir et valoir ce que de droit.
        
        Fait à __________, le {today}
        """
        
        story.append(Paragraph(text, self.normal_style))
        story.append(Spacer(1, 3*cm))
        
        signature_text = "Le Directeur de la scolarité"
        story.append(Paragraph(signature_text, self.normal_style))
        
        # Footer
        footer_text = "Document généré automatiquement - Ne pas modifier"
        story.append(Spacer(1, 5*cm))
        story.append(Paragraph(footer_text, self.header_style))
        
        doc.build(story)
        return filename
        
    def generate_releve_notes(self, student_data, grades_data):
        """Génère un relevé de notes"""
        filename = f"{self.output_dir}/releve_notes_{student_data['NUM_ETUDIANT']}.pdf"
        doc = SimpleDocTemplate(filename, pagesize=A4)
        story = []
        
        # En-tête
        if os.path.exists("resources/images/logo_universite.png"):
            img = Image("resources/images/logo_universite.png", width=5*cm, height=2*cm)
            story.append(img)
        
        story.append(Spacer(1, 0.5*cm))
        story.append(Paragraph("RELEVÉ DE NOTES", self.title_style))
        story.append(Spacer(1, 0.5*cm))
        
        # Informations étudiant
        student_info = [
            ["Nom:", student_data['NOM']],
            ["Prénom:", student_data['PRENOM']],
            ["N° étudiant:", student_data['NUM_ETUDIANT']],
            ["Formation:", student_data['LIBELLE_FORMATION']],
            ["Année universitaire:", student_data['ANNEE_UNIV']]
        ]
        
        t = Table(student_info, colWidths=[4*cm, 10*cm])
        t.setStyle(TableStyle([
            ('GRID', (0, 0), (-1, -1), 0.25, colors.grey),
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey)
        ]))
        story.append(t)
        story.append(Spacer(1, 1*cm))
        
        # Tableau des notes
        grades_table_data = [["UE", "Libellé", "Crédits", "Note", "Résultat"]]
        
        for grade in grades_data:
            grades_table_data.append([
                grade['CODE_UE'],
                grade['LIBELLE_UE'],
                grade['CREDITS_ECTS'],
                grade['NOTE_UE'],
                grade['RESULTAT']
            ])
            
        # Ajouter moyenne générale
        grades_table_data.append([
            "TOTAL",
            "",
            sum(g['CREDITS_ECTS'] for g in grades_data),
            f"{sum(g['NOTE_UE'] * g['CREDITS_ECTS'] for g in grades_data) / sum(g['CREDITS_ECTS'] for g in grades_data):.2f}",
            "ADMIS" if all(g['RESULTAT'] == "ADM" for g in grades_data) else "AJOURNÉ"
        ])
        
        t = Table(grades_table_data, colWidths=[2*cm, 8*cm, 2*cm, 2*cm, 3*cm])
        t.setStyle(TableStyle([
            ('GRID', (0, 0), (-1, -1), 0.25, colors.grey),
            ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
            ('BACKGROUND', (0, -1), (-1, -1), colors.lightgrey)
        ]))
        story.append(t)
        
        # Signature
        story.append(Spacer(1, 2*cm))
        today = datetime.datetime.now().strftime("%d/%m/%Y")
        signature_text = f"Fait à __________, le {today}\nLe Directeur des études"
        story.append(Paragraph(signature_text, self.normal_style))
        
        doc.build(story)
        return filename