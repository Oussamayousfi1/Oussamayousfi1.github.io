# Récupération des informations d'un étudiant
def get_student_info(student_id):
    query = """
    SELECT 
        e.NUM_ETUDIANT, 
        e.NOM, 
        e.PRENOM, 
        e.DATE_NAISSANCE,
        e.LIEU_NAISSANCE,
        e.NATIONALITE,
        ia.CODE_FORMATION,
        ia.ANNEE_UNIV,
        f.LIBELLE_FORMATION
    FROM 
        INDIVIDU e
        JOIN INSCRIPTION_ADMINISTRATIVE ia ON e.COD_IND = ia.COD_IND
        JOIN FORMATION f ON ia.CODE_FORMATION = f.CODE_FORMATION
    WHERE 
        e.NUM_ETUDIANT = :student_id
        AND ia.ANNEE_UNIV = :academic_year
    """
    return query

# Récupération des notes d'un étudiant
def get_student_grades(student_id, academic_year):
    query = """
    SELECT 
        ue.CODE_UE,
        ue.LIBELLE_UE,
        n.NOTE_UE,
        n.RESULTAT,
        e.SESSION_EXAM,
        ue.CREDITS_ECTS
    FROM 
        NOTES n
        JOIN UE ue ON n.CODE_UE = ue.CODE_UE
        JOIN EXAMENS e ON n.COD_EXAM = e.COD_EXAM
        JOIN INSCRIPTION_PEDAGOGIQUE ip ON n.COD_IND = ip.COD_IND
        JOIN INDIVIDU i ON ip.COD_IND = i.COD_IND
    WHERE 
        i.NUM_ETUDIANT = :student_id
        AND ip.ANNEE_UNIV = :academic_year
    ORDER BY 
        ue.SEMESTRE, ue.CODE_UE
    """
    return query

# Vérification du statut de diplomation
def check_graduation_status(student_id, diploma_code):
    query = """
    SELECT 
        d.DATE_OBTENTION,
        d.MENTION,
        d.VALIDATION
    FROM 
        DIPLOMATION d
        JOIN INDIVIDU i ON d.COD_IND = i.COD_IND
    WHERE 
        i.NUM_ETUDIANT = :student_id
        AND d.CODE_DIPLOME = :diploma_code
    """
    return query