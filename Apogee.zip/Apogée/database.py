import oracledb
import os
from configparser import ConfigParser

class DatabaseConfig:
    def __init__(self, config_file="config/database.ini"):
        self.config_file = config_file
        self.config = None
        
        # Créer le fichier de configuration s'il n'existe pas
        if not os.path.exists(config_file):
            self._create_default_config()
        
        self._load_config()
    
    def _create_default_config(self):
        # Créer le répertoire si nécessaire
        os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
        
        config = ConfigParser()
        config["DATABASE"] = {
            "host": "localhost",
            "port": "1521",
            "service_name": "APOGEE",
            "user": "username",
            "password": "password",
            "encoding": "UTF8"
        }
        
        with open(self.config_file, 'w') as f:
            config.write(f)
    
    def _load_config(self):
        self.config = ConfigParser()
        self.config.read(self.config_file)
    
    def get_connection_string(self):
        db = self.config["DATABASE"]
        return f"{db['host']}:{db['port']}/{db['service_name']}"
    
    def get_credentials(self):
        db = self.config["DATABASE"]
        return db["user"], db["password"]
    
    def save_config(self, host, port, service_name, user, password, encoding="UTF8"):
        self.config["DATABASE"] = {
            "host": host,
            "port": port,
            "service_name": service_name,
            "user": user,
            "password": password,
            "encoding": encoding
        }
        
        with open(self.config_file, 'w') as f:
            self.config.write(f)

class DatabaseController:
    def __init__(self):
        self.config = DatabaseConfig()
        self.connection = None
    
    def connect(self):
        if self.connection and self.connection.ping():
            return True
            
        user, password = self.config.get_credentials()
        dsn = self.config.get_connection_string()
        
        try:
            self.connection = oracledb.connect(user=user, password=password, dsn=dsn)
            return True
        except Exception as e:
            print(f"Erreur de connexion: {str(e)}")
            raise
    
    def execute_query(self, query, params=None):
        if not self.connection:
            self.connect()
            
        cursor = self.connection.cursor()
        try:
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
                
            columns = [col[0] for col in cursor.description]
            results = []
            
            for row in cursor:
                results.append(dict(zip(columns, row)))
                
            return results
        finally:
            cursor.close()
    
    def get_student_info(self, student_id, academic_year=None):
        # Si l'année n'est pas précisée, utiliser l'année en cours
        if not academic_year:
            current_month = datetime.datetime.now().month
            current_year = datetime.datetime.now().year
            academic_year = f"{current_year-1}/{current_year}" if current_month < 9 else f"{current_year}/{current_year+1}"
        
        query = """
        SELECT 
            e.NUM_ETUDIANT, 
            e.NOM, 
            e.PRENOM, 
            TO_CHAR(e.DATE_NAISSANCE, 'DD/MM/YYYY') as DATE_NAISSANCE,
            e.LIEU_NAISSANCE,
            e.NATIONALITE,
            ia.CODE_FORMATION,
            ia.ANNEE_UNIV,
            f.LIBELLE_FORMATION
        FROM 
            INDIVIDU e
            JOIN INSCRIPTION_ADMINISTRATIVE ia ON e.COD_IND = ia.COD_IND
            JOIN FORMATION f ON ia.CODE_FORMATION = f.CODE_FORMATION
        WHERE 
            e.NUM_ETUDIANT = :student_id
            AND ia.ANNEE_UNIV = :academic_year
        """
        
        results = self.execute_query(query, {'student_id': student_id, 'academic_year': academic_year})
        return results[0] if results else None