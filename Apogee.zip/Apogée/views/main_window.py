import os
import sys
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                             QLabel, QLineEdit, QPushButton, QComboBox, 
                             QTabWidget, QTableWidget, QTableWidgetItem, 
                             QMessageBox, QFileDialog, QGroupBox, QFormLayout,
                             QCheckBox, QRadioButton, QButtonGroup, QAction,
                             QStatusBar, QSpacerItem, QSizePolicy, QDialog)
from PyQt5.QtCore import Qt, QDate, QSettings
from PyQt5.QtGui import QIcon, QPixmap

# Importer les modules de l'application
try:
    from views.login_dialog import LoginDialog
except ImportError:
    # Définition inline de LoginDialog si le module est manquant
    class LoginDialog(QDialog):
        def __init__(self, parent=None):
            super().__init__(parent)
            self.setWindowTitle("Connexion à Apogée")
            self.setMinimumWidth(400)
            self.init_ui()
            
        def init_ui(self):
            layout = QVBoxLayout(self)
            
            info_label = QLabel("Veuillez saisir vos identifiants pour la connexion")
            info_label.setWordWrap(True)
            layout.addWidget(info_label)
            
            form_layout = QFormLayout()
            
            self.host_input = QLineEdit("196.200.184.40")
            form_layout.addRow("Hôte (IP):", self.host_input)
            
            self.port_input = QLineEdit("1521")
            form_layout.addRow("Port:", self.port_input)
            
            self.sid_input = QLineEdit("apousms1")
            form_layout.addRow("SID:", self.sid_input)
            
            self.user_input = QLineEdit()
            form_layout.addRow("Utilisateur:", self.user_input)
            
            self.password_input = QLineEdit()
            self.password_input.setEchoMode(QLineEdit.Password)
            form_layout.addRow("Mot de passe:", self.password_input)
            
            layout.addLayout(form_layout)
            
            self.save_check = QCheckBox("Enregistrer ces identifiants")
            self.save_check.setChecked(True)
            layout.addWidget(self.save_check)
            
            self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
            self.buttons.accepted.connect(self.accept)
            self.buttons.rejected.connect(self.reject)
            layout.addWidget(self.buttons)
        
        def get_credentials(self):
            return {
                "host": self.host_input.text(),
                "port": self.port_input.text(),
                "sid": self.sid_input.text(),
                "user": self.user_input.text(),
                "password": self.password_input.text()
            }

from controllers.database import DatabaseController
from controllers.document_generator import DocumentGenerator
from config.database import DatabaseConfig

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Apogée - Gestion des documents académiques")
        self.setMinimumSize(800, 600)
        
        # Initialiser les composants
        self.init_ui()
        
        # Configurer la base de données
        self.db_config = DatabaseConfig()
        self.db_controller = DatabaseController(use_mock=True)  # Mode simulation par défaut
        
        # Générateur de documents
        self.doc_generator = DocumentGenerator()
        
        # Données courantes
        self.current_student_data = None
        self.current_grades_data = None
        
        # Tenter de se connecter à la base de données
        self.connect_to_database()
        
    def init_ui(self):
        # Widget central
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Barre de statut
        self.statusBar().showMessage("Prêt")
        
        # Menu
        self.init_menu()
        
        # Section de connexion à la base
        db_group = QGroupBox("Connexion à la base de données")
        db_layout = QHBoxLayout()
        
        self.db_status_label = QLabel("Déconnecté")
        self.db_status_label.setStyleSheet("color: red;")
        
        self.connect_button = QPushButton("Connecter")
        self.connect_button.clicked.connect(self.show_login_dialog)
        
        self.config_button = QPushButton("Configuration")
        self.config_button.clicked.connect(self.show_config_dialog)
        
        db_layout.addWidget(QLabel("Statut Base de Données:"))
        db_layout.addWidget(self.db_status_label)
        db_layout.addStretch()
        db_layout.addWidget(self.connect_button)
        db_layout.addWidget(self.config_button)
        
        db_group.setLayout(db_layout)
        main_layout.addWidget(db_group)
        
        # Section de recherche d'étudiant
        search_group = QGroupBox("Recherche d'étudiant")
        search_layout = QHBoxLayout()
        
        search_layout.addWidget(QLabel("Numéro étudiant:"))
        self.student_id_input = QLineEdit()
        self.student_id_input.setPlaceholderText("Entrez un numéro d'étudiant, CIN ou nom")
        search_layout.addWidget(self.student_id_input)
        
        search_layout.addWidget(QLabel("Année universitaire:"))
        self.academic_year_combo = QComboBox()
        
        # Ajouter les années universitaires (5 dernières années)
        current_year = QDate.currentDate().year()
        for year in range(current_year-4, current_year+1):
            self.academic_year_combo.addItem(f"{year}/{year+1}")
        
        # Sélectionner l'année en cours
        current_month = QDate.currentDate().month()
        if current_month < 9:  # Avant septembre, on est dans l'année universitaire précédente
            current_academic_year = f"{current_year-1}/{current_year}"
        else:
            current_academic_year = f"{current_year}/{current_year+1}"
        
        index = self.academic_year_combo.findText(current_academic_year)
        if index != -1:
            self.academic_year_combo.setCurrentIndex(index)
        
        search_layout.addWidget(self.academic_year_combo)
        
        self.search_button = QPushButton("Rechercher")
        self.search_button.clicked.connect(self.search_student)
        search_layout.addWidget(self.search_button)
        
        search_group.setLayout(search_layout)
        main_layout.addWidget(search_group)
        
        # Onglets pour l'information étudiant et les notes
        self.tabs = QTabWidget()
        
        # Onglet d'informations étudiant
        self.info_tab = QWidget()
        info_layout = QVBoxLayout(self.info_tab)
        
        # Tableau d'informations étudiant
        self.info_table = QTableWidget(0, 2)
        self.info_table.setHorizontalHeaderLabels(["Attribut", "Valeur"])
        self.info_table.horizontalHeader().setStretchLastSection(True)
        info_layout.addWidget(self.info_table)
        
        # Boutons pour générer les documents dans l'onglet d'informations
        info_buttons_layout = QHBoxLayout()
        
        self.generate_attestation_btn = QPushButton("Attestation de scolarité")
        self.generate_attestation_btn.clicked.connect(lambda: self.generate_document("Attestation de scolarité"))
        info_buttons_layout.addWidget(self.generate_attestation_btn)
        
        self.generate_success_btn = QPushButton("Attestation de réussite")
        self.generate_success_btn.clicked.connect(lambda: self.generate_document("Attestation de réussite"))
        info_buttons_layout.addWidget(self.generate_success_btn)
        
        info_layout.addLayout(info_buttons_layout)
        
        # Onglet des notes
        self.grades_tab = QWidget()
        grades_layout = QVBoxLayout(self.grades_tab)
        
        # Tableau des notes
        self.grades_table = QTableWidget(0, 5)
        self.grades_table.setHorizontalHeaderLabels(["Code", "Module", "Note", "Résultat", "ECTS"])
        self.grades_table.horizontalHeader().setStretchLastSection(True)
        grades_layout.addWidget(self.grades_table)
        
        # Bouton pour générer le relevé de notes
        grades_buttons_layout = QHBoxLayout()
        
        self.generate_grades_btn = QPushButton("Générer relevé de notes")
        self.generate_grades_btn.clicked.connect(lambda: self.generate_document("Relevé de notes"))
        grades_buttons_layout.addWidget(self.generate_grades_btn)
        
        grades_layout.addLayout(grades_buttons_layout)
        
        # Onglet pour la génération par lot
        self.batch_tab = QWidget()
        batch_layout = QVBoxLayout(self.batch_tab)
        
        batch_options_layout = QHBoxLayout()
        
        batch_options_layout.addWidget(QLabel("Formation:"))
        self.formation_combo = QComboBox()
        self.formation_combo.addItem("Toutes les formations")
        self.formation_combo.addItems([
            "Licence Informatique",
            "Master Informatique",
            "Licence Mathématiques",
            "Master Mathématiques",
            "Licence Économie",
            "Master Économie"
        ])
        batch_options_layout.addWidget(self.formation_combo)
        
        batch_options_layout.addWidget(QLabel("Document:"))
        self.batch_doc_combo = QComboBox()
        self.batch_doc_combo.addItems([
            "Attestation de scolarité",
            "Relevé de notes",
            "Attestation de réussite"
        ])
        batch_options_layout.addWidget(self.batch_doc_combo)
        
        self.batch_search_btn = QPushButton("Rechercher étudiants")
        self.batch_search_btn.clicked.connect(self.search_students_for_batch)
        batch_options_layout.addWidget(self.batch_search_btn)
        
        batch_layout.addLayout(batch_options_layout)
        
        # Tableau des étudiants pour traitement par lot
        self.batch_table = QTableWidget(0, 4)
        self.batch_table.setHorizontalHeaderLabels(["Numéro", "Nom", "Prénom", "Formation"])
        self.batch_table.horizontalHeader().setStretchLastSection(True)
        batch_layout.addWidget(self.batch_table)
        
        # Boutons pour la génération par lot
        batch_buttons_layout = QHBoxLayout()
        
        self.select_all_btn = QPushButton("Sélectionner tout")
        self.select_all_btn.clicked.connect(self.select_all_students)
        batch_buttons_layout.addWidget(self.select_all_btn)
        
        self.deselect_all_btn = QPushButton("Désélectionner tout")
        self.deselect_all_btn.clicked.connect(self.deselect_all_students)
        batch_buttons_layout.addWidget(self.deselect_all_btn)
        
        self.generate_batch_btn = QPushButton("Générer les documents")
        self.generate_batch_btn.clicked.connect(self.generate_batch_documents)
        batch_buttons_layout.addWidget(self.generate_batch_btn)
        
        batch_layout.addLayout(batch_buttons_layout)
        
        # Ajouter les onglets
        self.tabs.addTab(self.info_tab, "Informations étudiant")
        self.tabs.addTab(self.grades_tab, "Notes")
        self.tabs.addTab(self.batch_tab, "Génération par lot")
        
        main_layout.addWidget(self.tabs)
        
        # Initialiser les états de boutons
        self.enable_document_generation(False)
    
    def init_menu(self):
        menubar = self.menuBar()
        
        # Menu Fichier
        file_menu = menubar.addMenu('&Fichier')
        
        connect_action = QAction('Connecter à la base', self)
        connect_action.triggered.connect(self.show_login_dialog)
        file_menu.addAction(connect_action)
        
        config_action = QAction('Configuration', self)
        config_action.triggered.connect(self.show_config_dialog)
        file_menu.addAction(config_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction('Quitter', self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Menu Outils
        tools_menu = menubar.addMenu('&Outils')
        
        mode_action = QAction('Mode simulation', self)
        mode_action.setCheckable(True)
        mode_action.setChecked(True)
        mode_action.triggered.connect(self.toggle_mock_mode)
        tools_menu.addAction(mode_action)
        
        # Menu Aide
        help_menu = menubar.addMenu('&Aide')
        
        about_action = QAction('À propos', self)
        about_action.triggered.connect(self.show_about_dialog)
        help_menu.addAction(about_action)
    
    def connect_to_database(self):
        try:
            if self.db_controller.connect():
                self.db_status_label.setText("Connecté")
                self.db_status_label.setStyleSheet("color: green;")
                
                # Tester l'accès à la base
                if not self.db_controller.use_mock:
                    access_status = self.db_controller.check_database_access()
                    print(f"Statut d'accès: {access_status}")
                
                return True
            else:
                self.db_status_label.setText("Déconnecté")
                self.db_status_label.setStyleSheet("color: red;")
                return False
        except Exception as e:
            QMessageBox.critical(self, "Erreur de connexion", 
                                f"Impossible de se connecter à la base de données: {str(e)}")
            self.db_status_label.setText("Erreur")
            self.db_status_label.setStyleSheet("color: red;")
            return False
    
    def show_login_dialog(self):
        dialog = LoginDialog(self)
        if dialog.exec_():
            credentials = dialog.get_credentials()
            
            # Sauvegarder les identifiants si demandé
            if dialog.save_check.isChecked():
                self.db_config.save_config(
                    host=credentials['host'],
                    port=credentials['port'],
                    sid=credentials['sid'],
                    user=credentials['user'],
                    password=credentials['password']
                )
            
            # Configurer et connecter le contrôleur de base de données
            self.db_controller.use_mock = False
            self.db_controller.credentials = credentials
            self.connect_to_database()
    
    def show_config_dialog(self):
        QMessageBox.information(self, "Configuration",
                            "La configuration se fait via la boîte de dialogue de connexion.")
        self.show_login_dialog()
    
    def toggle_mock_mode(self, checked):
        if checked:
            self.db_controller.use_mock = True
            self.db_status_label.setText("Mode simulation")
            self.db_status_label.setStyleSheet("color: blue;")
        else:
            self.db_controller.use_mock = False
            self.connect_to_database()
    
    def search_student(self):
        search_term = self.student_id_input.text().strip()
        if not search_term:
            QMessageBox.warning(self, "Attention", "Veuillez saisir un terme de recherche")
            return
        
        academic_year = self.academic_year_combo.currentText()
        
        try:
            self.statusBar().showMessage(f"Recherche de l'étudiant avec le terme '{search_term}'...")
            
            # Vérifier l'accès à la base
            if not self.db_controller.use_mock and self.db_controller.is_connected:
                access_status = self.db_controller.check_database_access()
                print(f"Statut d'accès: {access_status}")
            
            # Rechercher l'étudiant avec la nouvelle méthode
            student_data = self.db_controller.search_student(search_term, academic_year)
            
            if student_data:
                self.display_student_info(student_data)
                self.current_student_data = student_data
                
                # Récupérer également les notes
                student_id = student_data.get('NUM_ETUDIANT') or student_data.get('COD_ETU')
                if student_id:
                    self.current_grades_data = self.db_controller.get_student_grades(
                        student_id, academic_year.split('/')[0] if '/' in academic_year else academic_year
                    )
                else:
                    self.current_grades_data = []
                
                self.statusBar().showMessage(f"Étudiant trouvé: {student_data.get('NOM')} {student_data.get('PRENOM')}")
                
                # Activer les boutons de génération de documents
                self.enable_document_generation(True)
                
                # Si l'onglet actuel est l'onglet des notes, mettre à jour l'affichage
                if hasattr(self, 'tabs') and self.tabs.currentIndex() == 1:
                    self.display_grades()
            else:
                QMessageBox.information(
                    self, 
                    "Aucun résultat", 
                    f"Aucun étudiant trouvé avec '{search_term}' pour l'année {academic_year}.\n\n"
                    f"Suggestions:\n"
                    f"- Vérifiez le numéro d'étudiant\n"
                    f"- Essayez une autre année universitaire\n"
                    f"- Recherchez par nom de famille ou CIN"
                )
                self.current_student_data = None
                self.current_grades_data = None
                
                # Désactiver les boutons de génération de documents
                self.enable_document_generation(False)
        except Exception as e:
            QMessageBox.critical(self, "Erreur", f"Erreur lors de la recherche: {str(e)}")
            import traceback
            traceback.print_exc()
    
    def enable_document_generation(self, enabled=True):
        """Active ou désactive les boutons de génération de documents"""
        if hasattr(self, 'generate_attestation_btn'):
            self.generate_attestation_btn.setEnabled(enabled)
        if hasattr(self, 'generate_grades_btn'):
            self.generate_grades_btn.setEnabled(enabled)
        if hasattr(self, 'generate_success_btn'):
            self.generate_success_btn.setEnabled(enabled)
    
    def display_student_info(self, student_data):
        """Affiche les informations de l'étudiant dans le tableau"""
        self.info_table.setRowCount(0)
        
        # Définir les attributs à afficher
        attributes = [
            ("Numéro d'étudiant", "NUM_ETUDIANT"),
            ("Nom", "NOM"),
            ("Prénom", "PRENOM"),
            ("Date de naissance", "DATE_NAISSANCE"),
            ("Lieu de naissance", "LIB_VIL_NAI_ETU"),
            ("Numéro INE", "COD_NNE_IND"),
            ("CIN", "CIN_IND"),
            ("Année universitaire", "COD_ANU"),
            ("Formation", "LIB_ETP"),
            ("Composante", "LIB_CMP")
        ]
        
        row = 0
        for attr_label, attr_key in attributes:
            if attr_key in student_data and student_data[attr_key]:
                self.info_table.insertRow(row)
                self.info_table.setItem(row, 0, QTableWidgetItem(attr_label))
                self.info_table.setItem(row, 1, QTableWidgetItem(str(student_data[attr_key])))
                row += 1
        
        # Ajuster la largeur des colonnes
        self.info_table.resizeColumnsToContents()
        
        # Si l'onglet des notes est actif, afficher également les notes
        if self.tabs.currentIndex() == 1:
            self.display_grades()
    
    def display_grades(self):
        """Affiche les notes de l'étudiant dans le tableau des notes"""
        self.grades_table.setRowCount(0)
        
        if not self.current_grades_data:
            return
        
        for row, grade in enumerate(self.current_grades_data):
            self.grades_table.insertRow(row)
            self.grades_table.setItem(row, 0, QTableWidgetItem(grade.get("COD_ELP", "")))
            self.grades_table.setItem(row, 1, QTableWidgetItem(grade.get("LIB_ELP", "")))
            self.grades_table.setItem(row, 2, QTableWidgetItem(str(grade.get("NOT_ELP", ""))))
            self.grades_table.setItem(row, 3, QTableWidgetItem(grade.get("RES_ELP", "")))
            self.grades_table.setItem(row, 4, QTableWidgetItem(str(grade.get("CRD_ELP", ""))))
        
        # Ajuster la largeur des colonnes
        self.grades_table.resizeColumnsToContents()
    
    def generate_document(self, doc_type):
        """Génère un document pour l'étudiant courant"""
        if not self.current_student_data:
            QMessageBox.warning(self, "Attention", "Aucun étudiant sélectionné")
            return
        
        try:
            # Générer le document
            output_path = self.doc_generator.generate(
                doc_type=doc_type,
                student_data=self.current_student_data,
                grades_data=self.current_grades_data if doc_type == "Relevé de notes" else None,
                language="Français",
                output_format="PDF",
                include_logo=True,
                include_signature=True
            )
            
            QMessageBox.information(
                self, 
                "Document généré", 
                f"Le document a été généré avec succès:\n{output_path}"
            )
            
        except Exception as e:
            QMessageBox.critical(
                self, 
                "Erreur", 
                f"Une erreur s'est produite lors de la génération du document:\n{str(e)}"
            )
    
    def search_students_for_batch(self):
        """Recherche des étudiants pour la génération par lot"""
        formation = self.formation_combo.currentText()
        academic_year = self.academic_year_combo.currentText()
        
        try:
            # Récupérer la liste des étudiants
            students = self.db_controller.get_student_list(
                formation if formation != "Toutes les formations" else None,
                academic_year
            )
            
            # Afficher les étudiants dans le tableau
            self.batch_table.setRowCount(0)
            
            for row, student in enumerate(students):
                self.batch_table.insertRow(row)
                
                # Ajouter une case à cocher dans la première colonne
                check_item = QTableWidgetItem()
                check_item.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
                check_item.setCheckState(Qt.Unchecked)
                self.batch_table.setItem(row, 0, check_item)
                
                # Ajouter les informations de l'étudiant
                self.batch_table.setItem(row, 0, QTableWidgetItem(student.get("NUM_ETUDIANT", "")))
                self.batch_table.setItem(row, 1, QTableWidgetItem(student.get("NOM", "")))
                self.batch_table.setItem(row, 2, QTableWidgetItem(student.get("PRENOM", "")))
                self.batch_table.setItem(row, 3, QTableWidgetItem(student.get("LIB_ETP", "")))
            
            # Ajuster la largeur des colonnes
            self.batch_table.resizeColumnsToContents()
            
            self.statusBar().showMessage(f"{len(students)} étudiants trouvés")
            
        except Exception as e:
            QMessageBox.critical(
                self, 
                "Erreur", 
                f"Une erreur s'est produite lors de la recherche des étudiants:\n{str(e)}"
            )
    
    def select_all_students(self):
        """Sélectionne tous les étudiants dans le tableau"""
        for row in range(self.batch_table.rowCount()):
            item = self.batch_table.item(row, 0)
            if item:
                item.setCheckState(Qt.Checked)
    
    def deselect_all_students(self):
        """Désélectionne tous les étudiants dans le tableau"""
        for row in range(self.batch_table.rowCount()):
            item = self.batch_table.item(row, 0)
            if item:
                item.setCheckState(Qt.Unchecked)
    
    def generate_batch_documents(self):
        """Génère des documents pour les étudiants sélectionnés"""
        selected_students = []
        
        for row in range(self.batch_table.rowCount()):
            item = self.batch_table.item(row, 0)
            if item and item.checkState() == Qt.Checked:
                student_id = item.text()
                selected_students.append(student_id)
        
        if not selected_students:
            QMessageBox.warning(
                self, 
                "Attention", 
                "Aucun étudiant sélectionné"
            )
            return
        
        # Sélectionner le dossier de destination
        output_dir = QFileDialog.getExistingDirectory(
            self, 
            "Sélectionner le dossier de destination", 
            os.path.expanduser("~"),
            QFileDialog.ShowDirsOnly
        )
        
        if not output_dir:
            return
        
        # Type de document à générer
        doc_type = self.batch_doc_combo.currentText()
        academic_year = self.academic_year_combo.currentText()
        
        # Compteur de réussite
        success_count = 0
        
        # Générer les documents
        for student_id in selected_students:
            try:
                # Récupérer les données de l'étudiant
                student_data = self.db_controller.get_student_info(student_id, academic_year)
                
                if not student_data:
                    continue
                
                # Récupérer les notes si nécessaire
                grades_data = None
                if doc_type == "Relevé de notes":
                    grades_data = self.db_controller.get_student_grades(
                        student_id, 
                        academic_year.split('/')[0] if '/' in academic_year else academic_year
                    )
                
                # Générer le document
                output_path = os.path.join(
                    output_dir, 
                    f"{doc_type.replace(' ', '_')}_{student_data.get('NOM', '')}.pdf"
                )
                
                self.doc_generator.generate(
                    doc_type=doc_type,
                    student_data=student_data,
                    grades_data=grades_data,
                    output_path=output_path
                )
                
                success_count += 1
                
            except Exception as e:
                print(f"Erreur pour l'étudiant {student_id}: {str(e)}")
        
        QMessageBox.information(
            self, 
            "Documents générés", 
            f"{success_count}/{len(selected_students)} documents ont été générés avec succès dans le dossier:\n{output_dir}"
        )
    
    def show_about_dialog(self):
        """Affiche la boîte de dialogue À propos"""
        QMessageBox.about(
            self,
            "À propos",
            "Apogée - Gestion des documents académiques\n\n"
            "Version 1.0\n\n"
            "Cette application permet de générer des documents académiques\n"
            "à partir des données du système Apogée.\n\n"
            "Développé par Oussama Yousfi"
        )