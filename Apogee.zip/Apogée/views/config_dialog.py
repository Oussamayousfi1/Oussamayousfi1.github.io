from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QFormLayout,
                           QLineEdit, QDialogButtonBox,
                           QLabel, QCheckBox, QHBoxLayout)

class LoginDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Connexion à Apogée")
        self.setMinimumWidth(400)
        self.init_ui()
        
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # Message d'information
        info_label = QLabel(
            "Veuillez saisir vos identifiants pour la connexion à la base de données Apogée."
        )
        info_label.setWordWrap(True)
        layout.addWidget(info_label)
        
        # Formulaire
        form_layout = QFormLayout()
        
        self.host_input = QLineEdit("196.200.184.40")
        form_layout.addRow("Hôte (IP):", self.host_input)
        
        self.port_input = QLineEdit("1521")
        form_layout.addRow("Port:", self.port_input)
        
        self.sid_input = QLineEdit("apousms1")
        form_layout.addRow("SID:", self.sid_input)
        
        self.user_input = QLineEdit()
        form_layout.addRow("Nom d'utilisateur:", self.user_input)
        
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        form_layout.addRow("Mot de passe:", self.password_input)
        
        layout.addLayout(form_layout)
        
        # Option pour sauvegarder les identifiants
        save_layout = QHBoxLayout()
        self.save_check = QCheckBox("Enregistrer ces identifiants")
        self.save_check.setChecked(True)
        save_layout.addWidget(self.save_check)
        layout.addLayout(save_layout)
        
        # Boutons
        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        layout.addWidget(self.buttons)
    
    def get_credentials(self):
        return {
            "host": self.host_input.text(),
            "port": self.port_input.text(),
            "sid": self.sid_input.text(),
            "user": self.user_input.text(),
            "password": self.password_input.text()
        }