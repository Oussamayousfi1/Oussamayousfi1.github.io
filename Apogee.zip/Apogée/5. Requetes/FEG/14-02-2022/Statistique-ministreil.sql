SELECT
    apogee.individu.cod_etu,
    apogee.individu.cin_ind,
    apogee.individu.cod_nne_ind,
    apogee.individu.lib_pr1_ind,
    apogee.individu.lib_nom_pat_ind,
    apogee.individu.date_nai_ind,
    apogee.individu.cod_sex_etu,
    apogee.individu.cod_pay_nat,
    apogee.individu.cod_dep_pay_nai,
    apogee.individu.cod_thp,
    apogee.ind_bac.cod_bac,
    apogee.ind_bac.cod_dep,
    apogee.ind_bac.daa_obt_bac_iba,
    apogee.ind_bac.cod_tpe,
    apogee.ins_adm_anu.cod_pcs_etudiant,
    apogee.ins_adm_anu.cod_pcs_parent,
    apogee.ins_adm_anu.cod_pcs_mere,
    apogee.adresse.cod_dep AS cod_dep1,
    apogee.ins_adm_etp.cod_anu,
    apogee.ins_adm_etp.cod_cmp,
    apogee.ins_adm_etp.eta_iae,
    apogee.ins_adm_etp.nbr_ins_dip,
    apogee.ins_adm_etp.cod_dip
FROM
         apogee.individu
    INNER JOIN apogee.ins_adm_anu ON apogee.ins_adm_anu.cod_ind = apogee.individu.cod_ind
    INNER JOIN apogee.ins_adm_etp ON apogee.ins_adm_etp.cod_ind = apogee.ins_adm_anu.cod_ind
                                     AND apogee.ins_adm_etp.cod_anu = apogee.ins_adm_anu.cod_anu
    INNER JOIN apogee.ind_bac ON apogee.ind_bac.cod_ind = apogee.ins_adm_etp.cod_ind
    INNER JOIN apogee.adresse ON apogee.adresse.cod_ind = apogee.individu.cod_ind
WHERE
        apogee.ins_adm_etp.cod_anu = '2021'
    AND apogee.ins_adm_etp.cod_cmp = 'FGB'
    AND apogee.ins_adm_etp.eta_iae = 'E'