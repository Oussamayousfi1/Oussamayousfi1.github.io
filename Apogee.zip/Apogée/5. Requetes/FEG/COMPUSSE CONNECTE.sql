SELECT apogee.ins_adm_etp.COD_ANU,
  apogee.ins_adm_etp.COD_DIP,
  apogee.individu.COD_NNE_IND,
  apogee.individu.CIN_IND,
  apogee.individu.LIB_NOM_PAT_IND,
  apogee.individu.LIB_PR1_IND,
  apogee.individu.DATE_NAI_IND,
  apogee.individu.LIB_VIL_NAI_ETU,
  apogee.ins_adm_etp.ETA_IAE,
  apogee.ins_adm_etp.COD_VRS_VET,
  apogee.ins_adm_etp.COD_ETP
FROM apogee.individu
INNER JOIN apogee.ins_adm_anu
ON apogee.individu.COD_IND = apogee.ins_adm_anu.COD_IND
INNER JOIN apogee.ins_adm_etp
ON apogee.ins_adm_anu.COD_IND    = apogee.ins_adm_etp.COD_IND
WHERE apogee.ins_adm_etp.COD_ANU = '2021'
AND apogee.ins_adm_etp.COD_DIP   = 'FESEG'
AND apogee.ins_adm_etp.ETA_IAE   = 'E'
