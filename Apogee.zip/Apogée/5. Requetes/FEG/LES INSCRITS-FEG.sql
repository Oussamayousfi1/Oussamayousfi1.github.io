SELECT
    apogee.individu.cod_etu,
    apogee.individu.cod_nne_ind,
    apogee.individu.cin_ind,
    apogee.individu.lib_nom_pat_ind,
    apogee.individu.lib_pr1_ind,
    apogee.ins_adm_etp.cod_anu,
    apogee.individu.date_nai_ind,
    apogee.ins_adm_etp.cod_etp,
    apogee.ins_adm_etp.eta_iae,
    apogee.ind_bac.daa_obt_bac_iba,
    apogee.ins_adm_etp.nbr_ins_cyc,
    apogee.ins_adm_etp.nbr_ins_dip,
    apogee.ind_bac.cod_mnb,
    apogee.adresse.num_tel,
    apogee.adresse.cod_mil_adr,
    apogee.adresse.lib_ade,
    apogee.ins_adm_etp.cod_uti
FROM
    apogee.individu
    INNER JOIN apogee.ins_adm_anu ON apogee.individu.cod_ind = apogee.ins_adm_anu.cod_ind
    INNER JOIN apogee.ins_adm_etp ON apogee.ins_adm_anu.cod_anu = apogee.ins_adm_etp.cod_anu
                                     AND apogee.ins_adm_anu.cod_ind = apogee.ins_adm_etp.cod_ind
    INNER JOIN apogee.ind_bac ON apogee.ind_bac.cod_ind = apogee.individu.cod_ind
    INNER JOIN apogee.adresse ON apogee.individu.cod_ind = apogee.adresse.cod_ind
WHERE
    apogee.ins_adm_etp.cod_anu = '2021'
    AND apogee.ins_adm_etp.eta_iae = 'E'
    AND apogee.ins_adm_etp.cod_dip LIKE 'FESEG'