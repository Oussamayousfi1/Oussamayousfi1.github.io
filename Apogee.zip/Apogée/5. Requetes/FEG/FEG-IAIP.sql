SELECT
    apogee.ins_adm_etp.cod_anu,
    apogee.ins_adm_etp.cod_dip,
    apogee.bac_oux_equ.lic_bac,
    apogee.individu.cod_nne_ind,
    apogee.individu.cin_ind,
    apogee.individu.lib_nom_pat_ind,
    apogee.individu.lib_pr1_ind,
    apogee.individu.date_nai_ind,
    apogee.individu.lib_vil_nai_etu,
    apogee.ins_adm_etp.eta_iae,
    apogee.ins_adm_etp.cod_vrs_vet,
    apogee.ins_adm_etp.cod_etp
FROM
         apogee.individu
    INNER JOIN apogee.ins_adm_anu ON apogee.individu.cod_ind = apogee.ins_adm_anu.cod_ind
    INNER JOIN apogee.ins_adm_etp ON apogee.ins_adm_anu.cod_ind = apogee.ins_adm_etp.cod_ind,
    apogee.bac_oux_equ
WHERE
        apogee.ins_adm_etp.cod_anu = '2021'
    AND apogee.ins_adm_etp.cod_dip = 'FESEG'
    AND apogee.ins_adm_anu.cod_anu = '2021'
    AND apogee.ins_adm_etp.eta_iae = 'E'