import os
import sys
import platform
import traceback

# Afficher les informations de diagnostic
print("=== INFORMATIONS SYSTÈME ===")
print(f"Python version: {platform.python_version()}")
print(f"System: {platform.system()} {platform.release()}")
print(f"Architecture: {platform.architecture()}")

# Ajouter le chemin vers Oracle Instant Client au PATH
oracle_client_path = r"C:\oracle\instantclient"  # AJUSTEZ CE CHEMIN
os.environ['PATH'] = oracle_client_path + ';' + os.environ['PATH']

print("\n=== VÉRIFICATION DES CHEMINS ===")
print(f"Chemin Oracle Client configuré: {oracle_client_path}")
print(f"Le dossier existe: {os.path.exists(oracle_client_path)}")

if os.path.exists(oracle_client_path):
    files = os.listdir(oracle_client_path)
    print(f"Fichiers trouvés: {len(files)}")
    dll_files = [f for f in files if f.endswith('.dll')]
    print(f"Fichiers DLL: {dll_files}")
    if 'oci.dll' in dll_files:
        print("✓ oci.dll trouvé")
    else:
        print("✗ oci.dll MANQUANT")

# Tentative d'importation de cx_Oracle
print("\n=== TEST D'IMPORTATION ===")
try:
    import cx_Oracle
    print(f"✓ cx_Oracle importé avec succès, version: {cx_Oracle.__version__}")
except Exception as e:
    print(f"✗ Erreur lors de l'importation de cx_Oracle: {e}")
    sys.exit(1)

# Connexion à la base de données
print("\n=== TEST DE CONNEXION ===")
# Informations de connexion - utilisez vos valeurs réelles
username = "OYOUSFI"  # Remplacez par votre nom d'utilisateur
password = "Geolier123"  # Remplacez par votre mot de passe
host = "196.200.184.40"  # Serveur Apogée
port = "1521"  # Port standard Oracle
sid = "apousms1"  # SID Apogée

# Construction du DSN
dsn = cx_Oracle.makedsn(host, port, sid=sid)
print(f"DSN généré: {dsn}")

# Essai de connexion
try:
    print("Tentative de connexion...")
    connection = cx_Oracle.connect(user=username, password=password, dsn=dsn)
    print("✓ CONNEXION RÉUSSIE!")
    
    # Test de requête
    cursor = connection.cursor()
    cursor.execute("SELECT SYSDATE FROM DUAL")
    result = cursor.fetchone()
    print(f"Date du serveur Oracle: {result[0]}")
    
    cursor.close()
    connection.close()
except Exception as e:
    print(f"✗ ERREUR DE CONNEXION: {e}")
    print("\nTraceback complet:")
    traceback.print_exc()
    
    print("\n=== SUGGESTIONS DE DÉPANNAGE ===")
    if "DPI-1047" in str(e):
        print("1. Vérifiez que Oracle Instant Client est correctement installé")
        print("2. Assurez-vous que le chemin est correct dans le script")
        print("3. Essayez de redémarrer votre ordinateur")
        print("4. Utilisez la même architecture (32 ou 64 bits) pour Python et Oracle Client")
    elif "DPI-1017" in str(e):
        print("Erreur d'authentification: vérifiez votre nom d'utilisateur et mot de passe")
    elif "DPI-1010" in str(e):
        print("Erreur de connexion réseau: vérifiez l'adresse IP, le port et le pare-feu")
    elif "DPI-1080" in str(e):
        print("Erreur de SID/service_name: vérifiez que le SID est correct")
