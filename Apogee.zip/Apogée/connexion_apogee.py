import oracledb  # ou import cx_Oracle pour les versions plus anciennes

# Configuration de la connexion
username = "votre_utilisateur"
password = "votre_mot_de_passe"
dsn = "adresse_ip_serveur:port/nom_service"  # Exemple: "192.168.1.100:1521/APOGEE"

# Établir la connexion
connection = oracledb.connect(user=username, password=password, dsn=dsn)

# Exemple de requête pour récupérer des informations sur un étudiant
def get_student_info(student_id):
    cursor = connection.cursor()
    query = """
    SELECT e.NOM, e.PRENOM, e.DATE_NAISS, i.CODE_FORMATION
    FROM ETUDIANTS e
    JOIN INSCRIPTIONS i ON e.ID_ETUDIANT = i.ID_ETUDIANT
    WHERE e.NUM_ETUDIANT = :id
    """
    cursor.execute(query, id=student_id)
    result = cursor.fetchone()
    cursor.close()
    return result

# Exemple de fonction pour générer une attestation
def generate_attestation(student_id):
    student_data = get_student_info(student_id)
    if student_data:
        # Utiliser une bibliothèque comme ReportLab pour générer le PDF
        # ...
        return True
    return False