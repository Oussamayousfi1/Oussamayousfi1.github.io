# Ce fichier permet � Python de reconna�tre le dossier comme un package
