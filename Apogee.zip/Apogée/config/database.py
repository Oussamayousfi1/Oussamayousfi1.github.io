import os
import configparser

class DatabaseConfig:
    def __init__(self):
        self.config_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "database.ini")
        self.config = self.load_config()
    
    def load_config(self):
        config = configparser.ConfigParser()
        
        if os.path.exists(self.config_file):
            config.read(self.config_file)
        else:
            # Créer une configuration par défaut
            config['DATABASE'] = {
                'host': '196.200.184.40',
                'port': '1521',
                'sid': 'apousms1',
                'user': '',
                'password': '',
                'encoding': 'UTF8'
            }
            
            # Créer le dossier de configuration si nécessaire
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            
            # Sauvegarder la configuration
            with open(self.config_file, 'w') as configfile:
                config.write(configfile)
        
        return config
    
    def save_config(self, host=None, port=None, sid=None, user=None, password=None):
        if 'DATABASE' not in self.config:
            self.config['DATABASE'] = {}
        
        if host:
            self.config['DATABASE']['host'] = host
        if port:
            self.config['DATABASE']['port'] = port
        if sid:
            self.config['DATABASE']['sid'] = sid
        if user:
            self.config['DATABASE']['user'] = user
        if password:
            self.config['DATABASE']['password'] = password
        
        # Sauvegarder la configuration
        os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
        with open(self.config_file, 'w') as configfile:
            self.config.write(configfile)
    
    def get_credentials(self):
        if 'DATABASE' in self.config:
            return (
                self.config['DATABASE'].get('user', ''),
                self.config['DATABASE'].get('password', '')
            )
        return ('', '')