import sys
import os

# Assurer que tous les dossiers nécessaires existent
directories = ['config', 'controllers', 'views', 'resources', 
               os.path.join('resources', 'images'), 
               os.path.join('resources', 'templates')]

for directory in directories:
    os.makedirs(directory, exist_ok=True)

# Créer les fichiers __init__.py s'ils n'existent pas
for package_dir in ['config', 'controllers', 'views']:
    init_file = os.path.join(package_dir, '__init__.py')
    if not os.path.exists(init_file):
        with open(init_file, 'w') as f:
            pass  # Créer un fichier vide

try:
    from PyQt5.QtWidgets import QApplication
    from views.main_window import MainWindow
    
    if __name__ == "__main__":
        app = QApplication(sys.argv)
        window = MainWindow()
        window.show()
        sys.exit(app.exec_())
except ModuleNotFoundError as e:
    print(f"Erreur: Module manquant - {e}")
    print("\nIl semble que votre installation Python soit incomplète ou endommagée.")
    print("Recommandations:")
    print("1. Réinstallez Python 3.9 ou 3.10 (versions plus stables que 3.13)")
    print("2. Assurez-vous d'avoir installé PyQt5 (pip install PyQt5)")
    print("\nPour continuer avec la version simplifiée, installez PyQt5:")
    print("  python -m pip install PyQt5")
    input("\nAppuyez sur Entrée pour quitter...")