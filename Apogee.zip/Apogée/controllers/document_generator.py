import os
import datetime
import tempfile
import shutil

class DocumentGenerator:
    def __init__(self):
        # Initialiser les ressources
        self.resources_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "resources")
        self.templates_dir = os.path.join(self.resources_dir, "templates")
        self.images_dir = os.path.join(self.resources_dir, "images")
        
        # Créer les dossiers s'ils n'existent pas
        os.makedirs(self.templates_dir, exist_ok=True)
        os.makedirs(self.images_dir, exist_ok=True)
    
    def generate(self, doc_type, student_data, grades_data=None, language="Français", 
                 output_format="PDF", include_logo=True, include_signature=True, 
                 output_path=None):
        """
        Génère un document académique en format texte
        
        Args:
            doc_type (str): Type de document ('Attestation de scolarité', 'Relevé de notes', etc.)
            student_data (dict): Données de l'étudiant
            grades_data (list, optional): Liste des notes de l'étudiant
            language (str, optional): Langue du document
            output_format (str, optional): Format de sortie ('PDF', 'Word')
            include_logo (bool, optional): Inclure le logo de l'université
            include_signature (bool, optional): Inclure la signature du doyen
            output_path (str, optional): Chemin du fichier de sortie
            
        Returns:
            str: Chemin du document généré
        """
        # Déterminer le chemin de sortie
        if not output_path:
            # Générer un nom de fichier basé sur le type de document et l'étudiant
            student_name = student_data.get('NOM', 'inconnu')
            filename = f"{doc_type.replace(' ', '_')}_{student_name}.txt"
            
            # Utiliser le bureau comme emplacement par défaut
            desktop = os.path.join(os.path.expanduser('~'), 'Desktop')
            if not os.path.exists(desktop):
                desktop = os.path.join(os.path.expanduser('~'), 'Documents')
            
            output_path = os.path.join(desktop, filename)
        else:
            # Assurer que le format est .txt quelle que soit l'extension demandée
            base, ext = os.path.splitext(output_path)
            output_path = base + ".txt"
        
        # Générer un fichier texte simple
        with open(output_path, 'w', encoding='utf-8') as f:
            # En-tête
            f.write("=" * 70 + "\n")
            f.write(f"{'UNIVERSITÉ EXEMPLE':^70}\n")
            f.write(f"{'FACULTÉ DES SCIENCES':^70}\n")
            f.write("=" * 70 + "\n\n")
            
            # Titre du document
            f.write(f"{doc_type.upper():^70}\n\n")
            
            # Informations de l'étudiant
            f.write("-" * 70 + "\n")
            f.write(f"Numéro d'étudiant: {student_data.get('NUM_ETUDIANT', '')}\n")
            f.write(f"Nom: {student_data.get('NOM', '')}\n")
            f.write(f"Prénom: {student_data.get('PRENOM', '')}\n")
            f.write(f"Date de naissance: {student_data.get('DATE_NAISSANCE', '')}\n")
            f.write(f"Formation: {student_data.get('LIB_ETP', '')}\n")
            f.write(f"Année universitaire: {student_data.get('COD_ANU', '')}\n")
            f.write("-" * 70 + "\n\n")
            
            # Contenu spécifique au type de document
            if doc_type == "Attestation de scolarité":
                f.write(
                    f"Je soussigné, le Doyen de la Faculté des Sciences, atteste que l'étudiant(e) "
                    f"{student_data.get('PRENOM', '')} {student_data.get('NOM', '')} est régulièrement "
                    f"inscrit(e) pour l'année universitaire {student_data.get('COD_ANU', '')} en "
                    f"{student_data.get('LIB_ETP', '')}.\n\n"
                )
            
            elif doc_type == "Relevé de notes" and grades_data:
                f.write(f"{'Module':<40}{'Note':^10}{'Résultat':^12}{'ECTS':^8}\n")
                f.write("-" * 70 + "\n")
                
                for grade in grades_data:
                    module = grade.get("LIB_ELP", "")[:38]
                    note = str(grade.get("NOT_ELP", ""))
                    resultat = grade.get("RES_ELP", "")
                    ects = str(grade.get("CRD_ELP", ""))
                    
                    f.write(f"{module:<40}{note:^10}{resultat:^12}{ects:^8}\n")
                
                f.write("\n")
                
                # Calcul de la moyenne
                total_points = 0
                total_coef = 0
                
                for grade in grades_data:
                    try:
                        note = float(grade.get("NOT_ELP", 0))
                        coef = float(grade.get("CRD_ELP", 1))
                        total_points += note * coef
                        total_coef += coef
                    except (ValueError, TypeError):
                        pass
                
                if total_coef > 0:
                    moyenne = total_points / total_coef
                    f.write(f"\nMoyenne générale: {moyenne:.2f}/20\n")
            
            elif doc_type == "Attestation de réussite":
                f.write(
                    f"Je soussigné, le Doyen de la Faculté des Sciences, atteste que l'étudiant(e) "
                    f"{student_data.get('PRENOM', '')} {student_data.get('NOM', '')} a validé avec succès "
                    f"l'année {student_data.get('LIB_ETP', '')} pour l'année universitaire "
                    f"{student_data.get('COD_ANU', '')}.\n\n"
                )
            
            # Date et signature
            f.write("\n\n")
            f.write(f"{'Fait à Exemple, le ' + datetime.datetime.now().strftime('%d/%m/%Y'):>70}\n\n")
            f.write(f"{'Le Doyen':>70}\n")
            if include_signature:
                f.write(f"{'[Signature]':>70}\n")
                
        print(f"Document généré: {output_path}")
        
        # Créer une copie avec l'extension demandée pour la compatibilité avec le code existant
        if output_format.lower() == "pdf":
            pdf_path = os.path.splitext(output_path)[0] + ".pdf.txt"
            shutil.copy2(output_path, pdf_path)
            return pdf_path
        elif output_format.lower() == "word":
            docx_path = os.path.splitext(output_path)[0] + ".docx.txt"
            shutil.copy2(output_path, docx_path)
            return docx_path
        else:
            return output_path
            
    def _generate_pdf(self, *args, **kwargs):
        """Méthode factice pour la compatibilité avec le code existant"""
        return self.generate(*args, **kwargs)
        
    def _generate_word(self, *args, **kwargs):
        """Méthode factice pour la compatibilité avec le code existant"""
        return self.generate(*args, **kwargs)