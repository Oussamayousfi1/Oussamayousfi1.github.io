import datetime
import random
import os
import cx_Oracle

class DatabaseController:
    def __init__(self, use_mock=True, credentials=None):
        self.use_mock = use_mock
        self.credentials = credentials
        self.connection = None
        self.is_connected = False
        
    def connect(self):
        if self.use_mock:
            print("Mode simulation: connexion simulée à Apogée")
            self.is_connected = True
            return True
        else:
            try:
                if self.credentials:
                    # Utiliser les identifiants fournis
                    user = self.credentials.get("user")
                    password = self.credentials.get("password")
                    host = self.credentials.get("host")
                    port = self.credentials.get("port")
                    sid = self.credentials.get("sid")
                else:
                    # Utiliser les identifiants du fichier de configuration
                    from config.database import DatabaseConfig
                    db_config = DatabaseConfig()
                    user, password = db_config.get_credentials()
                    config = db_config.config["DATABASE"]
                    host = config.get("host")
                    port = config.get("port")
                    sid = config.get("sid")
                
                # Construction du DSN
                dsn = cx_Oracle.makedsn(host, port, sid=sid)
                print(f"Tentative de connexion avec DSN: {dsn}")
                
                # Connexion à la base de données
                self.connection = cx_Oracle.connect(user=user, password=password, dsn=dsn)
                self.is_connected = True
                print("Connexion réussie à la base de données Oracle")
                return True
            except Exception as e:
                print(f"Erreur de connexion: {str(e)}")
                self.is_connected = False
                raise
    
    def check_database_access(self):
        """Vérifie l'accès à la base de données en comptant les étudiants"""
        if not self.connection:
            return "Non connecté"
        
        try:
            cursor = self.connection.cursor()
            cursor.execute("SELECT COUNT(*) FROM APOGEE.INDIVIDU")
            result = cursor.fetchone()
            return f"Accès OK - {result[0]} étudiants trouvés"
        except Exception as e:
            return f"Erreur d'accès: {str(e)}"
    
    def search_student(self, search_term, academic_year=None):
        """
        Recherche un étudiant par numéro, nom ou CIN
        
        Args:
            search_term (str): Le terme de recherche (numéro, nom ou CIN)
            academic_year (str, optional): L'année universitaire (ex: '2022/2023')
        
        Returns:
            dict: Les informations de l'étudiant ou None si non trouvé
        """
        # Si l'année n'est pas précisée, utiliser l'année en cours
        if not academic_year:
            current_month = datetime.datetime.now().month
            current_year = datetime.datetime.now().year
            # Année universitaire au format '2022/2023'
            if current_month < 9:
                academic_year = f"{current_year-1}/{current_year}"
            else:
                academic_year = f"{current_year}/{current_year+1}"
        
        # Extraire l'année de début si le format est '2022/2023'
        year_start = academic_year.split('/')[0] if '/' in academic_year else academic_year
        
        if self.use_mock:
            # Mode simulation - retourner des données fictives
            return {
                'NUM_ETUDIANT': search_term,
                'COD_ETU': search_term,
                'NOM': 'EXEMPLAIRE',
                'PRENOM': 'Mohamed',
                'DATE_NAISSANCE': '01/01/2000',
                'LIB_VIL_NAI_ETU': 'Casablanca',
                'COD_NNE_IND': '1234567890A',
                'CIN_IND': 'AB123456',
                'COD_ANU': year_start,
                'COD_DIP': 'FESEG',
                'LIB_ETP': 'Licence en Sciences Économiques',
                'COD_CMP': 'FSEG',
                'LIB_CMP': 'Faculté des Sciences Économiques et de Gestion'
            }
        else:
            try:
                # Construction de la requête avec recherche élargie
                query = """
                SELECT 
                    IND.COD_ETU AS NUM_ETUDIANT,
                    IND.COD_ETU,
                    IND.LIB_NOM_PAT_IND AS NOM,
                    IND.LIB_PR1_IND AS PRENOM,
                    IND.DATE_NAI_IND AS DATE_NAISSANCE,
                    IND.LIB_VIL_NAI_ETU,
                    IND.COD_NNE_IND,
                    IND.CIN_IND,
                    IAE.COD_ANU,
                    IAE.COD_DIP,
                    DIP.LIB_DIP AS LIB_ETP,
                    IAE.COD_CMP,
                    CMP.LIB_CMP
                FROM 
                    APOGEE.INDIVIDU IND
                LEFT JOIN 
                    APOGEE.INS_ADM_ETP IAE ON IND.COD_IND = IAE.COD_IND AND IAE.COD_ANU = :year_start
                LEFT JOIN 
                    APOGEE.DIPLOME DIP ON IAE.COD_DIP = DIP.COD_DIP
                LEFT JOIN 
                    APOGEE.COMPOSANTE CMP ON IAE.COD_CMP = CMP.COD_CMP
                WHERE 
                    (IND.COD_ETU = :search_term 
                    OR IND.CIN_IND = :search_term
                    OR UPPER(IND.LIB_NOM_PAT_IND) LIKE UPPER(:name_search))
                """
                
                # Exécution de la requête
                cursor = self.connection.cursor()
                cursor.execute(query, {
                    'search_term': search_term, 
                    'name_search': f"%{search_term}%",
                    'year_start': year_start
                })
                
                # Récupérer les résultats
                columns = [col[0] for col in cursor.description]
                result = cursor.fetchone()
                
                if result:
                    # Créer un dictionnaire avec les noms de colonnes
                    student_data = dict(zip(columns, result))
                    
                    # Formater la date de naissance
                    if 'DATE_NAISSANCE' in student_data and isinstance(student_data['DATE_NAISSANCE'], datetime.datetime):
                        student_data['DATE_NAISSANCE'] = student_data['DATE_NAISSANCE'].strftime('%d/%m/%Y')
                        
                    return student_data
                else:
                    return None
                    
            except Exception as e:
                print(f"Erreur lors de la recherche d'étudiant: {str(e)}")
                import traceback
                traceback.print_exc()
                return None
    
    def get_student_info(self, student_id, academic_year=None):
        """
        Récupère les informations d'un étudiant basé sur son code étudiant
        
        Args:
            student_id (str): Le numéro d'étudiant (COD_ETU)
            academic_year (str, optional): L'année universitaire (ex: '2022/2023')
        
        Returns:
            dict: Les informations de l'étudiant
        """
        # Utiliser la méthode search_student qui est plus complète
        return self.search_student(student_id, academic_year)
    
    def get_student_grades(self, student_id, academic_year=None):
        """
        Récupère les notes d'un étudiant
        
        Args:
            student_id (str): Le numéro d'étudiant (COD_ETU)
            academic_year (str, optional): L'année universitaire (ex: '2022')
        
        Returns:
            list: Liste des notes de l'étudiant
        """
        # Si l'année n'est pas précisée, utiliser l'année en cours
        if not academic_year:
            current_month = datetime.datetime.now().month
            current_year = datetime.datetime.now().year
            academic_year = str(current_year) if current_month >= 9 else str(current_year - 1)
        
        if self.use_mock:
            # Générer des données fictives pour les tests
            modules = [
                {"CODE": "ECO101", "LIB": "Introduction à l'Économie", "COEF": 3, "ECTS": 6},
                {"CODE": "ECO201", "LIB": "Microéconomie", "COEF": 3, "ECTS": 6},
                {"CODE": "ECO202", "LIB": "Macroéconomie", "COEF": 3, "ECTS": 6},
                {"CODE": "STAT101", "LIB": "Statistiques", "COEF": 2, "ECTS": 4},
                {"CODE": "MATH101", "LIB": "Mathématiques pour l'économie", "COEF": 2, "ECTS": 4},
                {"CODE": "GES101", "LIB": "Introduction à la Gestion", "COEF": 2, "ECTS": 4}
            ]
            
            results = []
            for module in modules:
                note = round(random.uniform(8, 19), 2)
                results.append({
                    "COD_ETU": student_id,
                    "COD_ANU": academic_year,
                    "COD_ELP": module["CODE"],
                    "LIB_ELP": module["LIB"],
                    "NOT_ELP": note,
                    "RES_ELP": "ADM" if note >= 10 else "AJ",
                    "COEF": module["COEF"],
                    "CRD_ELP": module["ECTS"]
                })
            
            return results
        else:
            try:
                # Construction de la requête pour les notes
                query = """
                SELECT 
                    IND.COD_ETU,
                    RES.COD_ANU,
                    RES.COD_ELP,
                    ELP.LIB_ELP,
                    RES.NOT_ELP,
                    RES.RES_ELP,
                    RES.BAR_ELP AS COEF,
                    ELP.NBR_CRD_ELP AS CRD_ELP
                FROM 
                    APOGEE.INDIVIDU IND
                INNER JOIN 
                    APOGEE.RESULTAT_ELP RES ON IND.COD_IND = RES.COD_IND
                LEFT JOIN 
                    APOGEE.ELEMENT_PEDAGOGI ELP ON RES.COD_ELP = ELP.COD_ELP
                WHERE 
                    IND.COD_ETU = :student_id
                    AND RES.COD_ANU = :academic_year
                ORDER BY 
                    ELP.LIB_ELP
                """
                
                # Exécution de la requête
                cursor = self.connection.cursor()
                cursor.execute(query, {'student_id': student_id, 'academic_year': academic_year})
                
                # Récupérer les résultats
                columns = [col[0] for col in cursor.description]
                results = []
                
                for row in cursor.fetchall():
                    grade_data = dict(zip(columns, row))
                    results.append(grade_data)
                
                return results
                
            except Exception as e:
                print(f"Erreur lors de la récupération des notes: {str(e)}")
                import traceback
                traceback.print_exc()
                return []
    
    def get_student_list(self, formation=None, academic_year=None):
        """
        Récupère une liste d'étudiants selon les critères
        
        Args:
            formation (str, optional): Code ou libellé de la formation
            academic_year (str, optional): Année universitaire
        
        Returns:
            list: Liste des étudiants
        """
        # Si l'année n'est pas précisée, utiliser l'année en cours
        if not academic_year:
            current_month = datetime.datetime.now().month
            current_year = datetime.datetime.now().year
            academic_year = f"{current_year-1}/{current_year}" if current_month < 9 else f"{current_year}/{current_year+1}"
        
        # Extraire l'année de début si le format est '2022/2023'
        year_start = academic_year.split('/')[0] if '/' in academic_year else academic_year
        
        if self.use_mock:
            # Données de test
            students = [
                {"NUM_ETUDIANT": "20001234", "NOM": "DUPONT", "PRENOM": "Jean", "LIB_ETP": "Licence Économie"},
                {"NUM_ETUDIANT": "20001235", "NOM": "MARTIN", "PRENOM": "Sophie", "LIB_ETP": "Licence Économie"},
                {"NUM_ETUDIANT": "20001236", "NOM": "BERNARD", "PRENOM": "Thomas", "LIB_ETP": "Master Économie"},
                {"NUM_ETUDIANT": "20001237", "NOM": "PETIT", "PRENOM": "Emma", "LIB_ETP": "Master Économie"},
                {"NUM_ETUDIANT": "20001238", "NOM": "ROBERT", "PRENOM": "Lucas", "LIB_ETP": "Licence Gestion"},
                {"NUM_ETUDIANT": "20001239", "NOM": "RICHARD", "PRENOM": "Alice", "LIB_ETP": "Licence Gestion"},
                {"NUM_ETUDIANT": "20001240", "NOM": "DURAND", "PRENOM": "Louis", "LIB_ETP": "Master Gestion"},
                {"NUM_ETUDIANT": "20001241", "NOM": "DUBOIS", "PRENOM": "Léa", "LIB_ETP": "Master Gestion"},
                {"NUM_ETUDIANT": "20001242", "NOM": "MOREAU", "PRENOM": "Hugo", "LIB_ETP": "Licence MIAGE"},
                {"NUM_ETUDIANT": "20001243", "NOM": "SIMON", "PRENOM": "Camille", "LIB_ETP": "Licence MIAGE"}
            ]
            
            # Filtrer par formation si spécifié
            if formation and formation != "Toutes les formations":
                students = [s for s in students if formation.lower() in s["LIB_ETP"].lower()]
                
            return students
        else:
            try:
                # Préparation de la requête
                query = """
                SELECT 
                    IND.COD_ETU AS NUM_ETUDIANT,
                    IND.LIB_NOM_PAT_IND AS NOM,
                    IND.LIB_PR1_IND AS PRENOM,
                    DIP.LIB_DIP AS LIB_ETP
                FROM 
                    APOGEE.INDIVIDU IND
                INNER JOIN 
                    APOGEE.INS_ADM_ETP IAE ON IND.COD_IND = IAE.COD_IND
                LEFT JOIN 
                    APOGEE.DIPLOME DIP ON IAE.COD_DIP = DIP.COD_DIP
                WHERE 
                    IAE.COD_ANU = :year_start
                    AND IAE.ETA_IAE = 'E'
                """
                
                # Ajouter le filtre de formation si nécessaire
                params = {'year_start': year_start}
                if formation and formation != "Toutes les formations":
                    query += " AND (UPPER(DIP.LIB_DIP) LIKE UPPER(:formation) OR IAE.COD_DIP = :formation_code)"
                    params['formation'] = f"%{formation}%"
                    params['formation_code'] = formation
                
                # Limiter le nombre de résultats pour éviter de surcharger l'interface
                query += " ORDER BY IND.LIB_NOM_PAT_IND, IND.LIB_PR1_IND FETCH FIRST 100 ROWS ONLY"
                
                # Exécution de la requête
                cursor = self.connection.cursor()
                cursor.execute(query, params)
                
                # Récupérer les résultats
                columns = [col[0] for col in cursor.description]
                results = []
                
                for row in cursor.fetchall():
                    student_data = dict(zip(columns, row))
                    results.append(student_data)
                
                return results
                
            except Exception as e:
                print(f"Erreur lors de la récupération de la liste des étudiants: {str(e)}")
                return []