import os
import sys

def ensure_directory(path):
    if not os.path.exists(path):
        os.makedirs(path)
        print(f"Dossier créé: {path}")

def ensure_file(path, content=""):
    directory = os.path.dirname(path)
    ensure_directory(directory)
    if not os.path.exists(path):
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"Fichier créé: {path}")

def create_init_files():
    for folder in ['config', 'controllers', 'views']:
        init_path = os.path.join(folder, '__init__.py')
        ensure_file(init_path)

def create_login_dialog():
    content = '''from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QFormLayout,
                           QLineEdit, QDialogButtonBox,
                           QLabel, QCheckBox, QHBoxLayout)

class LoginDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Connexion à Apogée")
        self.setMinimumWidth(400)
        self.init_ui()
        
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # Message d'information
        info_label = QLabel(
            "Veuillez saisir vos identifiants pour la connexion à la base de données Apogée."
        )
        info_label.setWordWrap(True)
        layout.addWidget(info_label)
        
        # Formulaire
        form_layout = QFormLayout()
        
        self.host_input = QLineEdit("196.200.184.40")
        form_layout.addRow("Hôte (IP):", self.host_input)
        
        self.port_input = QLineEdit("1521")
        form_layout.addRow("Port:", self.port_input)
        
        self.sid_input = QLineEdit("apousms1")
        form_layout.addRow("SID:", self.sid_input)
        
        self.user_input = QLineEdit()
        form_layout.addRow("Nom d'utilisateur:", self.user_input)
        
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        form_layout.addRow("Mot de passe:", self.password_input)
        
        layout.addLayout(form_layout)
        
        # Option pour sauvegarder les identifiants
        save_layout = QHBoxLayout()
        self.save_check = QCheckBox("Enregistrer ces identifiants")
        self.save_check.setChecked(True)
        save_layout.addWidget(self.save_check)
        layout.addLayout(save_layout)
        
        # Boutons
        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        layout.addWidget(self.buttons)
    
    def get_credentials(self):
        return {
            "host": self.host_input.text(),
            "port": self.port_input.text(),
            "sid": self.sid_input.text(),
            "user": self.user_input.text(),
            "password": self.password_input.text()
        }'''
    
    ensure_file(os.path.join('views', 'login_dialog.py'), content)

# Créer la structure de base du projet
project_folders = ['config', 'controllers', 'views', 'resources', 
                  os.path.join('resources', 'images'), 
                  os.path.join('resources', 'templates')]

for folder in project_folders:
    ensure_directory(folder)

# Créer les fichiers __init__.py
create_init_files()

# Créer le fichier login_dialog.py
create_login_dialog()

print("\nStructure du projet initialisée avec succès!")
print("Vous pouvez maintenant lancer l'application avec: python main.py")